#!/bin/sh
# compile.sh compiles all C programs in this directory and sub-directories.
# Copyright (C) 2013  Andrei Gabriel Scherer

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

CFLAGS="$CFLAGS -lm"

find -iname '*.c' | while read line
do
	output="$(echo "$line" | sed 's/.c$//')"
	if test "$1" = "clean"
	then
		rm -f "$output"
	else
		gcc "$line" $CFLAGS -Wall -o "$output" && strip --strip-unneeded "$output"
	fi
done

exit 0
