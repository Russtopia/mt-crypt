/*
randstdevol performs and outputs statistics on input overlapping 8-bit integers.
Copyright (C) 2013  Andrei Gabriel Scherer

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include <stdio.h>
#include <math.h>
#include <stdint.h>

#define UINT8_TOT (UINT8_MAX + 1) // = 256

int main (void)
{
	// ! init
	uint16_t cluster[BUFSIZ];
	unsigned int i, k;
	unsigned int ret;

	// init
	unsigned long total = 0;
	double average = 0;
	double stdev = 0;
	double expect = 0;
	double aerror = 0;
	unsigned long count[UINT8_TOT] = {};
	double avg[UINT8_TOT] = {};

	// input loop
	while ((ret = fread (cluster, 2, BUFSIZ, stdin)))
	{
		for (i = 0; i < ret; i++)
		{
			for (k = 0; k < 8; k++)
			{
				count[cluster[i] & 0xff]++;
				cluster[i] >>= 1;
			}
			count[cluster[i]]++;
		}
	}

	// total calc
	for (i = 0; i < UINT8_TOT; i++)
	{
		total += count[i];
	}

	// average calc
	for (i = 0; i < UINT8_TOT; i++)
	{
		// do not divide by zero
		if (0 == count[i])
		{
			printf ("FAIL Average = %f +- %f\n", 0.0, 0.0);
			return 1;
		}
		avg[i] = 1.0 * total / count[i];
		average += avg[i];
	}
	average /= UINT8_TOT;

	// stdev calc
	for (i = 0; i < UINT8_TOT; i++)
	{
		stdev += pow ((avg[i] - average), 2);
	}
	stdev = sqrt (stdev / UINT8_TOT);

	// calc expected deviation using derived formula and absolute error
	expect = exp (-0.5000 * log(total) + 8.315); // 4 sig figs
	aerror = 0.044 * 3.290527 * expect; // 3.290527 stdevs = 99.9 %

	ret = 0;
	if (stdev < (expect - aerror) || stdev > (expect + aerror))
	{
		printf ("FAIL ");
		ret = 1;
	}
	else
	{
		printf ("PASS ");
	}
	printf ("Average = %f +- %f\n", average, stdev);

	return ret;
}
