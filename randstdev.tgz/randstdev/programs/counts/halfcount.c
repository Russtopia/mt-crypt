/*
halfcount outputs counts of input 4-bit integers.
Copyright (C) 2013  Andrei Gabriel Scherer

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include <stdio.h>
#include <math.h>
#include <stdint.h>

#define UINT4_TOT 16

int main (void)
{
	// ! init
	uint8_t cluster[BUFSIZ];
	unsigned int i;
	unsigned int ret;

	// init
	unsigned long count[UINT4_TOT] = {};

	// input loop
	while ((ret = fread (cluster, 1, BUFSIZ, stdin)))
	{
		for (i = 0; i < ret; i++)
		{
			count[cluster[i] & 0x0f]++;
			count[(cluster[i] & 0xf0) >> 4]++;
		}
	}

	// total calc
	for (i = 0; i < UINT4_TOT; i++)
	{
		printf ("%2u\t%lu\n", i, count[i]);
	}

	return 0;
}
